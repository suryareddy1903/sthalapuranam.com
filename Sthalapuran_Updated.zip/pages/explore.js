import ExplorePage from '@/components/ExplorePage'
export default function Explore() { return <ExplorePage /> }